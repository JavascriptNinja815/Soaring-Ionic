export interface User{
  parentName: string;
  email:string;
  password:string;
  timestamp: number;
}
