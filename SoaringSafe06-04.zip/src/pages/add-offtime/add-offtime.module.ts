import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddOfftimePage } from './add-offtime';

@NgModule({
  declarations: [
    AddOfftimePage,
  ],
  imports: [
    IonicPageModule.forChild(AddOfftimePage),
  ],
})
export class AddOfftimePageModule {}
