import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { JoshIphone6Page } from './josh-iphone6';

@NgModule({
  declarations: [
    JoshIphone6Page,
  ],
  imports: [
    IonicPageModule.forChild(JoshIphone6Page),
  ],
})
export class JoshIphone6PageModule {}
