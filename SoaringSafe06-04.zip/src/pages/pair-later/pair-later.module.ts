import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PairLaterPage } from './pair-later';

@NgModule({
  declarations: [
    PairLaterPage,
  ],
  imports: [
    IonicPageModule.forChild(PairLaterPage),
  ],
})
export class PairLaterPageModule {}
