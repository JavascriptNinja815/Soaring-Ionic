import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RewardJoshPage } from './reward-josh';

@NgModule({
  declarations: [
    RewardJoshPage,
  ],
  imports: [
    IonicPageModule.forChild(RewardJoshPage),
  ],
})
export class RewardJoshPageModule {}
