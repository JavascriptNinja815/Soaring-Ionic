import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RewardLateBedtimePage } from './reward-late-bedtime';

@NgModule({
  declarations: [
    RewardLateBedtimePage,
  ],
  imports: [
    IonicPageModule.forChild(RewardLateBedtimePage),
  ],
})
export class RewardLateBedtimePageModule {}
