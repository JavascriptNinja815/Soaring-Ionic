import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SignupForSoaringSafePage } from './signup-for-soaring-safe';

@NgModule({
  declarations: [
    SignupForSoaringSafePage,
  ],
  imports: [
    IonicPageModule.forChild(SignupForSoaringSafePage),
  ],
})
export class SignupForSoaringSafePageModule {}
