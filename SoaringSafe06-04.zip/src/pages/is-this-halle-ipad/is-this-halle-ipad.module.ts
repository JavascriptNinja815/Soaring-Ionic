import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { IsThisHalleIpadPage } from './is-this-halle-ipad';

@NgModule({
  declarations: [
    IsThisHalleIpadPage,
  ],
  imports: [
    IonicPageModule.forChild(IsThisHalleIpadPage),
  ],
})
export class IsThisHalleIpadPageModule {}
