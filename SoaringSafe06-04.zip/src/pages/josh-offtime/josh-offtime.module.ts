import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { JoshOfftimePage } from './josh-offtime';

@NgModule({
  declarations: [
    JoshOfftimePage,
  ],
  imports: [
    IonicPageModule.forChild(JoshOfftimePage),
  ],
})
export class JoshOfftimePageModule {}
