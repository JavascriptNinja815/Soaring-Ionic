export const firebaseConfig = {
    apiKey: "AIzaSyD2N_-0l3nvLx6iOgXz8HMrelQQs3IQYEM",
    authDomain: "soaringsafe.firebaseapp.com",
    databaseURL: "https://soaringsafe.firebaseio.com",
    projectId: "soaringsafe",
    storageBucket: "soaringsafe.appspot.com",
    messagingSenderId: "155233054235"
};